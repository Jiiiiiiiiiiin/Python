base = 2

def square(n):
    return base ** n